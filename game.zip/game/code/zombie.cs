﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace game
{
    public class Zombie
    {
        private Texture2D texture;
        private Vector2 position;
        private Vector2 velocity;
        private float speed = 2f; 

        public Vector2 Position { get { return position; } }

        public Zombie(Texture2D zombieTexture, Vector2 startingPosition, Vector2 playerPosition)
        {
            texture = zombieTexture;
            position = startingPosition;
            
            velocity = Vector2.Normalize(playerPosition - startingPosition) * speed;
        }

        public void Update()
        {
            
            position += velocity;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            
            spriteBatch.Draw(texture, position, Color.White);
        }
    }
}
