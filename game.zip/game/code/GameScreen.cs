﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace game
{
    public class GameScreen
    {
        private Texture2D background;
        private Player player;

        public GameScreen()
        {
            player = new Player();
        }

        public void LoadContent(ContentManager content)
        {
            background = content.Load<Texture2D>("grassBackground");
            player.LoadContent(content);
        }
        public void Update(GameTime gameTime)
        {
            player.Update(gameTime); 
        }
        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(background, new Vector2(0, 0), Color.White);
            player.Draw(spriteBatch); 
        }
    }
}
