﻿
using var game = new game.Game1();
game.Run();
